import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const roomTypes = await prisma.roomType.findMany({
      where: { propertyId: id }
    });
    return NextResponse.json(roomTypes);
  } catch (error: any) {
    console.error('Rooms API Error:', error);
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
