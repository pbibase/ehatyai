import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { transitionBookingStatus } from '@/lib/domain';

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;
    const userId = (session.user as any).id;

    // Fetch the booking
    const booking = await prisma.booking.findUnique({
      where: { id }
    });

    if (!booking) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Verify it belongs to the session user
    if (booking.userId !== userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Transition status to Cancelled (Centralized domain state logic)
    const newStatus = transitionBookingStatus(booking.status, 'Cancelled');

    // Update in database
    await prisma.booking.update({
      where: { id },
      data: {
        status: newStatus,
        holdExpiresAt: new Date(), // Release hold immediately if any
      }
    });

    console.log(`\n======================================================`);
    console.log(`[ALERT] Booking ${id} has been CANCELLED.`);
    console.log(`Status transitioned successfully.`);
    console.log(`======================================================\n`);

    return NextResponse.json({ success: true, message: 'Booking cancelled successfully' });
  } catch (error: any) {
    console.error('Cancel Booking Error:', error);
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
