import { describe, it, expect } from 'vitest';
import { transitionBookingStatus, calculatePriceBreakdown, isDuplicatePayment } from '../lib/domain';

describe('S1 - Domain Core', () => {
  describe('Booking Status Machine', () => {
    it('allows valid transitions', () => {
      // Draft -> Pending-Payment
      expect(transitionBookingStatus('Draft', 'Pending-Payment')).toBe('Pending-Payment');
      
      // Draft -> Confirmed (zero-amount bypass)
      expect(transitionBookingStatus('Draft', 'Confirmed')).toBe('Confirmed');
      
      // Pending-Payment -> Confirmed
      expect(transitionBookingStatus('Pending-Payment', 'Confirmed')).toBe('Confirmed');
      
      // Draft -> Cancelled
      expect(transitionBookingStatus('Draft', 'Cancelled')).toBe('Cancelled');
      
      // Pending-Payment -> Cancelled
      expect(transitionBookingStatus('Pending-Payment', 'Cancelled')).toBe('Cancelled');
    });

    it('throws on illegal transitions', () => {
      // Confirmed cannot transition to anything
      expect(() => transitionBookingStatus('Confirmed', 'Draft')).toThrow();
      expect(() => transitionBookingStatus('Confirmed', 'Pending-Payment')).toThrow();
      expect(() => transitionBookingStatus('Confirmed', 'Cancelled')).toThrow();
      
      // Cancelled cannot transition to anything
      expect(() => transitionBookingStatus('Cancelled', 'Draft')).toThrow();
      expect(() => transitionBookingStatus('Cancelled', 'Confirmed')).toThrow();
      
      // Pending-Payment cannot transition to Draft
      expect(() => transitionBookingStatus('Pending-Payment', 'Draft')).toThrow();
    });
  });

  describe('Money Math and Promos', () => {
    it('computes exact breakdown to 2 decimals', () => {
      const breakdown = calculatePriceBreakdown({
        roomRate: 1200.55,
        nights: 3,
        taxesRate: 0.07, // 7%
        fees: 50.00,
        promoCode: null,
      });

      expect(breakdown.basePrice).toBe(1200.55);
      expect(breakdown.nights).toBe(3);
      expect(breakdown.subtotal).toBe(3601.65);
      expect(breakdown.taxes).toBe(252.12); // 3601.65 * 0.07 = 252.1155 -> 252.12
      expect(breakdown.fees).toBe(50.00);
      expect(breakdown.discount).toBe(0.00);
      expect(breakdown.netAmount).toBe(3903.77); // 3601.65 + 252.12 + 50.00 = 3903.77
    });

    it('applies HATYAI100 discount (฿100 off)', () => {
      const breakdown = calculatePriceBreakdown({
        roomRate: 1000.00,
        nights: 2,
        taxesRate: 0.07,
        fees: 50.00,
        promoCode: { code: 'HATYAI100', discount: 100.00, isPercent: false },
      });

      // 2000 subtotal, 100 discount, net before taxes/fees = 1900? 
      // Wait, let's see how discount applies: usually discount applies to the subtotal before taxes/fees,
      // or to the net total. Let's apply it to the subtotal:
      // Subtotal = 2000. Discount = 100. Net Subtotal = 1900.
      // Taxes (7% of 1900) = 133. Fees = 50.
      // Net Amount = 1900 + 133 + 50 = 2083.
      // Let's implement it this way: discount is deducted from the subtotal.
      expect(breakdown.discount).toBe(100.00);
      expect(breakdown.subtotal).toBe(2000.00);
      expect(breakdown.taxes).toBe(133.00); // (2000 - 100) * 0.07 = 133
      expect(breakdown.netAmount).toBe(2083.00); // 1900 + 133 + 50 = 2083
    });

    it('applies FREESTAY100 discount (100% off)', () => {
      const breakdown = calculatePriceBreakdown({
        roomRate: 1000.00,
        nights: 2,
        taxesRate: 0.07,
        fees: 50.00,
        promoCode: { code: 'FREESTAY100', discount: 100.00, isPercent: true },
      });

      expect(breakdown.discount).toBe(2000.00); // 100% of subtotal
      expect(breakdown.netAmount).toBe(0.00); // Net amount must be 0
    });
  });

  describe('Payment Idempotency', () => {
    it('detects duplicate payments with same idempotency key', () => {
      const existingKeys = ['key-123', 'key-456'];
      expect(isDuplicatePayment('key-123', existingKeys)).toBe(true);
      expect(isDuplicatePayment('key-789', existingKeys)).toBe(false);
    });
  });
});
