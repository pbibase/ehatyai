'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/components/LanguageContext';
import { Calendar, Users, AlertTriangle } from 'lucide-react';

interface RoomType {
  id: string;
  name: string;
  capacity: number;
  basePrice: number;
}

interface Property {
  id: string;
  name: string;
  location: string;
  type: string;
}

interface PropertyDetailClientProps {
  property: Property;
  checkIn: string;
  checkOut: string;
  guests: string;
}

interface RoomAvailability {
  roomTypeId: string;
  available: boolean;
  remainingCount: number;
}

export default function PropertyDetailClient({
  property,
  checkIn: initialCheckIn,
  checkOut: initialCheckOut,
  guests: initialGuests,
}: PropertyDetailClientProps) {
  const router = useRouter();
  const { t } = useLanguage();

  const [checkIn, setCheckIn] = useState(initialCheckIn);
  const [checkOut, setCheckOut] = useState(initialCheckOut);
  const [guests, setGuests] = useState(initialGuests);
  const [roomTypes, setRoomTypes] = useState<RoomType[]>([]);
  const [availabilities, setAvailabilities] = useState<RoomAvailability[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateError, setDateError] = useState('');

  // Fetch property room types
  useEffect(() => {
    fetch(`/api/properties/${property.id}/rooms`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setRoomTypes(data);
        }
      })
      .catch(console.error);
  }, [property.id]);

  // Fetch real-time availability
  const fetchAvailability = () => {
    if (!checkIn || !checkOut) {
      setLoading(false);
      return;
    }

    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);

    if (checkOutDate <= checkInDate) {
      setDateError('Check-out date must be after check-in date');
      setLoading(false);
      return;
    }

    setDateError('');
    setLoading(true);

    fetch(`/api/properties/${property.id}/availability?checkIn=${checkIn}&checkOut=${checkOut}`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setAvailabilities(data);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchAvailability();
  }, [checkIn, checkOut, property.id]);

  const handleBookNow = (roomType: RoomType) => {
    // Save draft selection to session
    const draft = {
      propertyId: property.id,
      propertyName: property.name,
      roomTypeId: roomType.id,
      roomTypeName: roomType.name,
      basePrice: roomType.basePrice,
      checkIn,
      checkOut,
      guests: parseInt(guests),
    };
    
    sessionStorage.setItem('bookingDraft', JSON.stringify(draft));
    
    // Proceed to booking funnel (starts at step 5 login/registration)
    router.push('/booking');
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm mt-8">
      <h2 className="text-xl font-bold text-slate-900 border-b border-slate-100 pb-4">
        {t('details.rooms')}
      </h2>

      {/* Date selectors inside details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 p-4 rounded-xl bg-slate-50 border border-slate-100">
        <div>
          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-500">
            <Calendar className="h-3.5 w-3.5 text-blue-500" />
            {t('home.checkIn')}
          </label>
          <input
            type="date"
            value={checkIn}
            onChange={(e) => setCheckIn(e.target.value)}
            className="mt-2 h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm focus:border-blue-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-500">
            <Calendar className="h-3.5 w-3.5 text-blue-500" />
            {t('home.checkOut')}
          </label>
          <input
            type="date"
            value={checkOut}
            onChange={(e) => setCheckOut(e.target.value)}
            className="mt-2 h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm focus:border-blue-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-500">
            <Users className="h-3.5 w-3.5 text-blue-500" />
            {t('home.guests')}
          </label>
          <select
            value={guests}
            onChange={(e) => setGuests(e.target.value)}
            className="mt-2 h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm focus:border-blue-500 focus:outline-none"
          >
            <option value="1">1 person</option>
            <option value="2">2 persons</option>
            <option value="3">3 persons</option>
            <option value="4">4 persons</option>
            <option value="5">5 persons</option>
            <option value="6">6+ persons</option>
          </select>
        </div>
      </div>

      {dateError && (
        <div className="mt-4 p-3 rounded-lg bg-red-50 text-red-600 text-sm font-semibold flex items-center gap-2">
          <AlertTriangle className="h-4 w-4" />
          <span>{dateError}</span>
        </div>
      )}

      {/* Room Selection Table */}
      <div className="overflow-x-auto mt-6">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-100 text-slate-400 text-xs font-bold uppercase tracking-wider">
              <th className="pb-4">{t('review.roomType')}</th>
              <th className="pb-4">{t('review.guests')}</th>
              <th className="pb-4">{t('results.price')} / คืน</th>
              <th className="pb-4 text-center">สถานะ</th>
              <th className="pb-4 text-right">การจอง</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {loading ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-slate-400">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600 mx-auto"></div>
                </td>
              </tr>
            ) : roomTypes.length > 0 ? (
              roomTypes.map((rt) => {
                const availInfo = availabilities.find(a => a.roomTypeId === rt.id);
                const isAvailable = availInfo ? availInfo.available : false;
                const remaining = availInfo ? availInfo.remainingCount : 0;

                return (
                  <tr key={rt.id} className={`transition ${!isAvailable ? 'bg-slate-50/50 opacity-60' : 'hover:bg-slate-50/30'}`}>
                    <td className="py-4 font-semibold text-slate-900">{rt.name}</td>
                    <td className="py-4 text-slate-500">
                      {t('details.capacity', { capacity: rt.capacity })}
                    </td>
                    <td className="py-4 font-bold text-blue-600">฿{rt.basePrice.toFixed(2)}</td>
                    <td className="py-4 text-center">
                      {isAvailable ? (
                        <span className="inline-block text-xs font-semibold text-green-700 bg-green-50 border border-green-100 px-2.5 py-1 rounded-full">
                          {t('details.available', { count: remaining })}
                        </span>
                      ) : (
                        <span className="inline-block text-xs font-semibold text-red-700 bg-red-50 border border-red-100 px-2.5 py-1 rounded-full">
                          {t('details.soldOut')}
                        </span>
                      )}
                    </td>
                    <td className="py-4 text-right">
                      <button
                        onClick={() => handleBookNow(rt)}
                        disabled={!isAvailable}
                        className={`rounded-xl px-5 py-2 text-xs font-bold transition shadow-sm ${
                          isAvailable
                            ? 'bg-blue-600 text-white hover:bg-blue-700 hover:shadow-blue-500/10'
                            : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                        }`}
                      >
                        {t('details.bookNow')}
                      </button>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={5} className="py-8 text-center text-slate-400">
                  ไม่มีห้องพักสำหรับโรงแรมนี้
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
