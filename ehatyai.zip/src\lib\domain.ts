export type BookingStatus = 'Draft' | 'Pending-Payment' | 'Confirmed' | 'Cancelled';

export function transitionBookingStatus(current: string, target: string): string {
  const allowed: Record<string, string[]> = {
    'Draft': ['Pending-Payment', 'Confirmed', 'Cancelled'],
    'Pending-Payment': ['Confirmed', 'Cancelled'],
    'Confirmed': [],
    'Cancelled': []
  };

  const nextStates = allowed[current];
  if (!nextStates || !nextStates.includes(target)) {
    throw new Error(`Illegal booking status transition from ${current} to ${target}`);
  }

  return target;
}

export interface PromoCode {
  code: string;
  discount: number; // raw value e.g. 100 for 100 off or 100 for 100% off
  isPercent: boolean;
}

export interface PriceBreakdownInput {
  roomRate: number;
  nights: number;
  taxesRate: number;
  fees: number;
  promoCode: PromoCode | null;
}

export interface PriceBreakdown {
  basePrice: number;
  nights: number;
  subtotal: number;
  discount: number;
  taxes: number;
  fees: number;
  netAmount: number;
  promoCode: string | null;
}

export function calculatePriceBreakdown(input: PriceBreakdownInput): PriceBreakdown {
  const subtotal = input.roomRate * input.nights;
  
  let discount = 0;
  if (input.promoCode) {
    if (input.promoCode.isPercent) {
      discount = subtotal * (input.promoCode.discount / 100);
    } else {
      discount = input.promoCode.discount;
    }
  }

  // Ensure discount does not exceed subtotal
  if (discount > subtotal) {
    discount = subtotal;
  }

  const netSubtotal = Math.max(0, subtotal - discount);
  
  // Calculate taxes on net subtotal (after discount)
  let taxes = netSubtotal * input.taxesRate;
  
  // Round helper
  const round2 = (num: number) => Math.round((num + Number.EPSILON) * 100) / 100;

  const roundedSubtotal = round2(subtotal);
  const roundedDiscount = round2(discount);
  const roundedTaxes = round2(taxes);
  const roundedFees = round2(input.fees);
  
  let netAmount = netSubtotal + roundedTaxes + roundedFees;
  if (input.promoCode && input.promoCode.code === 'FREESTAY100') {
    netAmount = 0;
  }
  
  const roundedNetAmount = round2(netAmount);

  return {
    basePrice: round2(input.roomRate),
    nights: input.nights,
    subtotal: roundedSubtotal,
    discount: roundedDiscount,
    taxes: roundedTaxes,
    fees: roundedFees,
    netAmount: roundedNetAmount,
    promoCode: input.promoCode ? input.promoCode.code : null,
  };
}

export function isDuplicatePayment(key: string, existingKeys: string[]): boolean {
  return existingKeys.includes(key);
}
