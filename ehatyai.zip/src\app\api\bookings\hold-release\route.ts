import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const {
      userId,
      roomTypeId,
      checkIn,
      checkOut,
      guests,
      bookerName,
      bookerEmail,
      bookerPhone,
      specialRequests,
      priceBreakdown,
    } = await request.json();

    if (!userId || !roomTypeId || !checkIn || !checkOut || !guests || !bookerName || !bookerEmail || !bookerPhone) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Generate unique booking ID (BK-XXXXXX)
    const rand = Math.floor(100000 + Math.random() * 900000);
    const bookingId = `BK-${rand}`;

    // Create a Pending-Payment booking
    // Enforce BR-5: status is Pending-Payment, and the hold is released (holdExpiresAt set to now)
    const booking = await prisma.booking.create({
      data: {
        id: bookingId,
        userId,
        roomTypeId,
        checkIn: new Date(checkIn + 'T00:00:00.000Z'),
        checkOut: new Date(checkOut + 'T00:00:00.000Z'),
        guests,
        status: 'Pending-Payment',
        priceBreakdown,
        holdExpiresAt: new Date(), // Set to now (released immediately)
      }
    });

    // Create failed payment log
    const parsedBreakdown = JSON.parse(priceBreakdown);
    await prisma.payment.create({
      data: {
        bookingId: booking.id,
        method: 'card',
        amount: parsedBreakdown.netAmount,
        status: 'Failed',
        attempts: 3,
        gatewayRef: `gw_fail_${Math.random().toString(36).substring(7)}`,
      }
    });

    console.log(`\n======================================================`);
    console.log(`[ALERT] Booking ${bookingId} held as PENDING-PAYMENT.`);
    console.log(`Attempts exhausted. Room hold released for other customers.`);
    console.log(`======================================================\n`);

    return NextResponse.json({ 
      success: true, 
      bookingId: booking.id,
      message: 'Booking saved as Pending-Payment, hold released' 
    });
  } catch (error: any) {
    console.error('Hold Release Booking Error:', error);
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
