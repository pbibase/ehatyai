'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Navbar } from '@/components/Navbar';
import { useLanguage } from '@/components/LanguageContext';
import { MapPin, Calendar, Users, Search } from 'lucide-react';

const SUGGESTIONS = [
  'หาดใหญ่ (Hat Yai)',
  'สงขลา (Songkhla)',
  'ลีการ์เดนส์ (Lee Gardens)',
  'หาดสมิหลา (Samila Beach)',
  'คลองแห (Klong Hae)',
  'น้ำตกโตนงาช้าง (Ton Nga Chang)',
  'เมืองเก่าสงขลา (Songkhla Old Town)',
];

export default function Home() {
  const router = useRouter();
  const { t } = useLanguage();
  const [destination, setDestination] = useState('');
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState('2');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!destination.trim()) {
      setError(t('home.destination') + ' is required');
      return;
    }

    if (!checkIn || !checkOut) {
      setError('Please select check-in and check-out dates');
      return;
    }

    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);

    if (checkOutDate <= checkInDate) {
      setError('Check-out date must be after check-in date');
      return;
    }

    // Redirect to search results page
    const query = new URLSearchParams({
      destination: destination.split(' ')[0], // Pass clean string (e.g. 'หาดใหญ่')
      checkIn,
      checkOut,
      guests,
    });
    router.push(`/results?${query.toString()}`);
  };

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <Navbar />
      
      {/* Hero Section */}
      <main className="flex-1">
        <div className="relative overflow-hidden bg-gradient-to-b from-blue-500/20 via-transparent to-transparent py-20 sm:py-32">
          <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
            <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl md:text-6xl">
              <span className="block text-blue-600">{t('home.hero')}</span>
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600 sm:mt-6">
              จองห้องพักราคาพิเศษ ค้นหาง่าย สบายกระเป๋า เช็คอินฟรีกว่า 12 แห่งรอบหาดใหญ่และสงขลา
            </p>

            {/* Search Container */}
            <div className="mx-auto mt-12 max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-xl shadow-slate-100 sm:p-8">
              <form onSubmit={handleSearch} className="grid grid-cols-1 gap-4 sm:grid-cols-4">
                {/* Destination */}
                <div className="relative flex flex-col text-left">
                  <label htmlFor="destination" className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                    <MapPin className="h-3.5 w-3.5 text-blue-500" />
                    {t('home.destination')}
                  </label>
                  <input
                    type="text"
                    id="destination"
                    value={destination}
                    onChange={(e) => {
                      setDestination(e.target.value);
                      setShowSuggestions(true);
                    }}
                    onFocus={() => setShowSuggestions(true)}
                    onBlur={() => {
                      // Small delay to let clicks on suggestions register first
                      setTimeout(() => setShowSuggestions(false), 200);
                    }}
                    placeholder={t('home.placeholder')}
                    className="mt-2 h-11 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm focus:border-blue-500 focus:bg-white focus:outline-none"
                    autoComplete="off"
                  />
                  {showSuggestions && (
                    <div className="absolute top-[68px] z-50 w-full rounded-lg border border-slate-200 bg-white py-1 shadow-lg">
                      {SUGGESTIONS.filter(item => 
                        item.toLowerCase().includes(destination.toLowerCase())
                      ).map((item) => (
                        <button
                          key={item}
                          type="button"
                          onClick={() => {
                            setDestination(item);
                            setShowSuggestions(false);
                          }}
                          className="w-full px-4 py-2 text-left text-sm hover:bg-slate-50 text-slate-800"
                        >
                          {item}
                        </button>
                      ))}
                      {SUGGESTIONS.filter(item => 
                        item.toLowerCase().includes(destination.toLowerCase())
                      ).length === 0 && (
                        <div className="px-4 py-2 text-xs text-slate-500">พิมพ์ชื่อเพื่อค้นหา</div>
                      )}
                    </div>
                  )}
                </div>

                {/* Check In */}
                <div className="flex flex-col text-left">
                  <label htmlFor="checkIn" className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                    <Calendar className="h-3.5 w-3.5 text-blue-500" />
                    {t('home.checkIn')}
                  </label>
                  <input
                    type="date"
                    id="checkIn"
                    value={checkIn}
                    onChange={(e) => setCheckIn(e.target.value)}
                    className="mt-2 h-11 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                {/* Check Out */}
                <div className="flex flex-col text-left">
                  <label htmlFor="checkOut" className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                    <Calendar className="h-3.5 w-3.5 text-blue-500" />
                    {t('home.checkOut')}
                  </label>
                  <input
                    type="date"
                    id="checkOut"
                    value={checkOut}
                    onChange={(e) => setCheckOut(e.target.value)}
                    className="mt-2 h-11 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                {/* Guests */}
                <div className="flex flex-col text-left">
                  <label htmlFor="guests" className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                    <Users className="h-3.5 w-3.5 text-blue-500" />
                    {t('home.guests')}
                  </label>
                  <select
                    id="guests"
                    value={guests}
                    onChange={(e) => setGuests(e.target.value)}
                    className="mt-2 h-11 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm focus:border-blue-500 focus:bg-white focus:outline-none"
                  >
                    <option value="1">1 person</option>
                    <option value="2">2 persons</option>
                    <option value="3">3 persons</option>
                    <option value="4">4 persons</option>
                    <option value="5">5 persons</option>
                    <option value="6">6+ persons</option>
                  </select>
                </div>
              </form>

              {/* Error Message */}
              {error && (
                <div className="mt-4 text-left text-sm font-semibold text-red-500">
                  {error}
                </div>
              )}

              {/* Submit Button */}
              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleSearch}
                  id="search-btn"
                  className="flex items-center gap-2 rounded-xl bg-blue-600 px-8 py-3 text-sm font-bold text-white shadow-lg shadow-blue-500/20 transition hover:bg-blue-700 hover:shadow-blue-500/30"
                >
                  <Search className="h-4 w-4" />
                  <span>{t('home.search')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
