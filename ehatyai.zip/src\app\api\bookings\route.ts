import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { checkRoomAvailability } from '@/lib/inventory';

export async function POST(request: Request) {
  try {
    const {
      userId,
      roomTypeId,
      checkIn,
      checkOut,
      guests,
      bookerName,
      bookerEmail,
      bookerPhone,
      specialRequests,
      priceBreakdown,
      isZeroBypass,
      paymentMethod,
      idempotencyKey,
    } = await request.json();

    if (!userId || !roomTypeId || !checkIn || !checkOut || !guests || !bookerName || !bookerEmail || !bookerPhone) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // 1. Re-check availability (BR-6)
    const avail = await checkRoomAvailability(roomTypeId, checkIn, checkOut);
    if (!avail.available) {
      return NextResponse.json({ error: 'Selected room is no longer available' }, { status: 400 });
    }

    // 2. Enforce idempotency (BR-7)
    if (idempotencyKey) {
      const existing = await prisma.booking.findUnique({
        where: { idempotencyKey }
      });
      if (existing) {
        // Return existing booking directly if payment replayed
        return NextResponse.json({ 
          success: true, 
          bookingId: existing.id,
          message: 'Booking retrieved from cache'
        });
      }
    }

    // 3. Status Transition logic (Centralized state enforcement)
    // Create new booking with status Confirmed (since payment succeeded or zero-amount bypass)
    const status = 'Confirmed';
    
    // Generate unique booking ID (BK-XXXXXX)
    const rand = Math.floor(100000 + Math.random() * 900000);
    const bookingId = `BK-${rand}`;

    // Create the booking in DB
    const booking = await prisma.booking.create({
      data: {
        id: bookingId,
        userId,
        roomTypeId,
        checkIn: new Date(checkIn + 'T00:00:00.000Z'),
        checkOut: new Date(checkOut + 'T00:00:00.000Z'),
        guests,
        status,
        priceBreakdown,
        idempotencyKey: isZeroBypass ? null : idempotencyKey,
      }
    });

    // 4. Create payment entry in DB
    const parsedBreakdown = JSON.parse(priceBreakdown);
    if (!isZeroBypass) {
      await prisma.payment.create({
        data: {
          bookingId: booking.id,
          method: paymentMethod || 'card',
          amount: parsedBreakdown.netAmount,
          status: 'Success',
          attempts: 1,
          gatewayRef: `gw_${Math.random().toString(36).substring(7)}`,
        }
      });
    }

    // 5. Send Simulated Notifications (BR-7)
    const emailContent = `Dear ${bookerName}, your booking ${bookingId} at eHatyai.com has been CONFIRMED. Check-in: ${checkIn}.`;
    const smsContent = `eHatyai.com booking ${bookingId} CONFIRMED. Check-in ${checkIn}. QR: http://ehatyai.com/qr/${bookingId}`;

    await prisma.notification.create({
      data: {
        bookingId: booking.id,
        channel: 'email',
        deliveryStatus: 'Sent',
        content: emailContent
      }
    });

    await prisma.notification.create({
      data: {
        bookingId: booking.id,
        channel: 'sms',
        deliveryStatus: 'Sent',
        content: smsContent
      }
    });

    // Print to server console (Simulated Notification Gateway)
    console.log(`\n======================================================`);
    console.log(`[SIMULATED EMAIL GATEWAY] Sending to ${bookerEmail}...`);
    console.log(`Subject: Booking Confirmed - ${bookingId}`);
    console.log(`Body: ${emailContent}`);
    console.log(`======================================================`);
    console.log(`[SIMULATED SMS GATEWAY] Sending to ${bookerPhone}...`);
    console.log(`Message: ${smsContent}`);
    console.log(`======================================================\n`);

    return NextResponse.json({ 
      success: true, 
      bookingId: booking.id,
      message: 'Booking created and confirmed successfully' 
    });
  } catch (error: any) {
    console.error('Booking Creation Error:', error);
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
