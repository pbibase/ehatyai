'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Navbar } from '@/components/Navbar';
import { useLanguage } from '@/components/LanguageContext';
import { 
  Search, Calendar, User, CreditCard, ChevronRight, 
  CheckCircle2, AlertCircle, XCircle, RefreshCw 
} from 'lucide-react';

interface Booking {
  id: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  status: string;
  priceBreakdown: string;
  createdAt: string;
  roomType: {
    name: string;
    property: {
      name: string;
      location: string;
      photos: string;
    }
  }
}

export default function MyBookings() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const { t, language } = useLanguage();

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  // Fetch bookings
  useEffect(() => {
    if (status === 'authenticated') {
      fetchBookings();
    } else if (status === 'unauthenticated') {
      setLoading(false);
    }
  }, [status]);

  const fetchBookings = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/bookings/user');
      if (!res.ok) {
        throw new Error('Failed to load bookings');
      }
      const data = await res.json();
      setBookings(data);
    } catch (e: any) {
      setError(e.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelBooking = async (id: string) => {
    if (!confirm(t('mybookings.cancelConfirm') || 'Are you sure you want to cancel this booking?')) {
      return;
    }
    
    setCancellingId(id);
    try {
      const res = await fetch(`/api/bookings/${id}/cancel`, {
        method: 'POST',
      });
      
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to cancel booking');
      }
      
      // Update local state
      setBookings(prev => 
        prev.map(b => b.id === id ? { ...b, status: 'Cancelled' } : b)
      );
      if (selectedBooking?.id === id) {
        setSelectedBooking(prev => prev ? { ...prev, status: 'Cancelled' } : null);
      }
    } catch (e: any) {
      alert(e.message || 'Error cancelling booking');
    } finally {
      setCancellingId(null);
    }
  };

  // Filtered bookings
  const filteredBookings = bookings.filter(b => {
    const term = searchTerm.toLowerCase();
    const matchesId = b.id.toLowerCase().includes(term);
    const matchesProp = b.roomType.property.name.toLowerCase().includes(term);
    return matchesId || matchesProp;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Confirmed':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2.5 py-1 text-xs font-bold text-green-700 border border-green-100">
            <CheckCircle2 className="h-3.5 w-3.5" />
            <span>ยืนยันแล้ว</span>
          </span>
        );
      case 'Pending-Payment':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-bold text-amber-700 border border-amber-100">
            <AlertCircle className="h-3.5 w-3.5 animate-pulse" />
            <span>รอชำระเงิน</span>
          </span>
        );
      case 'Cancelled':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2.5 py-1 text-xs font-bold text-red-700 border border-red-100">
            <XCircle className="h-3.5 w-3.5" />
            <span>ยกเลิกแล้ว</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-50 px-2.5 py-1 text-xs font-bold text-slate-600 border border-slate-100">
            <AlertCircle className="h-3.5 w-3.5" />
            <span>{status}</span>
          </span>
        );
    }
  };

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString(language === 'th' ? 'th-TH' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      timeZone: 'UTC'
    });
  };

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen flex-col bg-slate-50">
        <Navbar />
        <div className="flex-1 flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return (
      <div className="flex min-h-screen flex-col bg-slate-50">
        <Navbar />
        <main className="flex-1 flex flex-col items-center justify-center py-20 text-center px-4">
          <div className="h-14 w-14 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mb-4">
            <User className="h-7 w-7" />
          </div>
          <h1 className="text-lg font-bold text-slate-800">กรุณาเข้าสู่ระบบเพื่อดูประวัติการจอง</h1>
          <button 
            onClick={() => router.push('/booking')} 
            className="mt-4 rounded-xl bg-blue-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-blue-700 shadow-md shadow-blue-500/10 transition"
          >
            เข้าสู่ระบบตอนนี้
          </button>
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <Navbar />

      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-black text-slate-900 leading-tight">ประวัติการจองห้องพัก</h1>
            <p className="text-slate-500 text-xs mt-1">จัดการการจองและตรวจสอบใบเสร็จการชำระเงินของคุณ</p>
          </div>

          {/* Search bar */}
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              id="search-bookings"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ค้นหาด้วยชื่อที่พัก หรือรหัสการจอง..."
              className="h-10 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-4 text-xs focus:border-blue-500 focus:outline-none shadow-sm"
            />
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : error ? (
          <div className="p-4 bg-red-50 border border-red-100 text-red-600 rounded-xl text-sm font-semibold">
            {error}
          </div>
        ) : filteredBookings.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
            <Calendar className="mx-auto h-12 w-12 text-slate-300 mb-4" />
            <p className="text-slate-800 font-bold">{t('results.empty') || 'ไม่พบรายการจอง'}</p>
            <p className="text-slate-400 text-xs mt-1">ลองเปลี่ยนคำค้นหา หรือค้นหาที่พักเพื่อจองใหม่</p>
            <button onClick={() => router.push('/')} className="mt-4 rounded-xl bg-blue-600 px-6 py-2.5 text-xs font-bold text-white hover:bg-blue-700">
              จองที่พักเลย
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {filteredBookings.map((b) => {
              const breakdown = JSON.parse(b.priceBreakdown);
              return (
                <div
                  key={b.id}
                  className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm hover:shadow-md transition flex flex-col md:flex-row justify-between gap-6"
                >
                  <div className="flex gap-4">
                    {/* Property Thumbnail */}
                    <div className="h-20 w-20 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0">
                      <img 
                        src={b.roomType.property.photos.split(',')[0]} 
                        alt={b.roomType.property.name} 
                        className="h-full w-full object-cover"
                      />
                    </div>

                    <div className="flex flex-col justify-between">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-black text-blue-600 tracking-wider uppercase">{b.id}</span>
                          {getStatusBadge(b.status)}
                        </div>
                        <h3 className="text-md font-extrabold text-slate-900 mt-1">
                          {b.roomType.property.name}
                        </h3>
                        <p className="text-slate-500 text-xs mt-0.5">{b.roomType.name}</p>
                      </div>

                      <div className="flex items-center gap-4 text-[10px] text-slate-400 font-semibold mt-3">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5 text-slate-400" />
                          <span>{formatDate(b.checkIn)} — {formatDate(b.checkOut)}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3.5 w-3.5 text-slate-400" />
                          <span>{b.guests} persons</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col justify-between items-end md:text-right border-t md:border-t-0 border-slate-100 pt-4 md:pt-0">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold">{t('review.net')}</span>
                      <span className="text-lg font-black text-slate-900">
                        ฿{(breakdown.netAmount || breakdown.basePrice || 0).toFixed(2)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-4">
                      {/* Cancel button */}
                      {(b.status === 'Confirmed' || b.status === 'Pending-Payment') && (
                        <button
                          onClick={() => handleCancelBooking(b.id)}
                          disabled={cancellingId === b.id}
                          className="rounded-lg border border-red-200 hover:bg-red-50 text-red-600 px-3.5 py-1.5 text-xs font-bold transition flex items-center gap-1"
                        >
                          {cancellingId === b.id && <RefreshCw className="h-3 w-3 animate-spin" />}
                          <span>ยกเลิก</span>
                        </button>
                      )}

                      <button
                        onClick={() => setSelectedBooking(b)}
                        className="rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 px-3.5 py-1.5 text-xs font-bold transition flex items-center gap-0.5"
                      >
                        <span>ดูรายละเอียด</span>
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Detail Modal Overlay */}
        {selectedBooking && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
            <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
              <div className="flex justify-between items-start border-b border-slate-100 pb-4 mb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-slate-900">{selectedBooking.id}</h3>
                    {getStatusBadge(selectedBooking.status)}
                  </div>
                  <p className="text-slate-400 text-[10px] font-semibold mt-0.5">
                    ทำรายการเมื่อ {new Date(selectedBooking.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedBooking(null)}
                  className="text-slate-400 hover:text-slate-600 font-bold text-sm"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4 text-sm text-slate-600">
                <div>
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">โรงแรม/ที่พัก</h4>
                  <p className="font-bold text-slate-800 text-md mt-1">{selectedBooking.roomType.property.name}</p>
                  <p className="text-xs text-slate-500">{selectedBooking.roomType.property.location}</p>
                </div>

                <div>
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">ห้องพักและรายละเอียด</h4>
                  <p className="font-bold text-slate-800 mt-1">{selectedBooking.roomType.name}</p>
                  <div className="flex gap-4 text-xs text-slate-500 mt-1">
                    <span>วันที่: {formatDate(selectedBooking.checkIn)} — {formatDate(selectedBooking.checkOut)}</span>
                    <span>ผู้เข้าพัก: {selectedBooking.guests} ท่าน</span>
                  </div>
                </div>

                {/* Price breakdown */}
                <div className="border-t border-slate-100 pt-4">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider mb-2">สรุปค่าใช้จ่าย</h4>
                  {(() => {
                    const bd = JSON.parse(selectedBooking.priceBreakdown);
                    return (
                      <div className="space-y-2 text-xs">
                        <div className="flex justify-between">
                          <span>ราคาห้องพัก ({bd.nights || 1} คืน)</span>
                          <span>฿{((bd.basePrice || bd.subtotal) * (bd.nights || 1)).toFixed(2)}</span>
                        </div>
                        {bd.discount > 0 && (
                          <div className="flex justify-between text-green-600 font-semibold">
                            <span>ส่วนลด ({bd.promoCode})</span>
                            <span>-฿{bd.discount.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span>ภาษี (7%)</span>
                          <span>฿{(bd.taxes || 0).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>ค่าธรรมเนียมบริการ</span>
                          <span>฿{(bd.fees || 0).toFixed(2)}</span>
                        </div>
                        <div className="border-t border-slate-100 pt-2 flex justify-between font-black text-sm text-slate-900">
                          <span>ยอดชำระสุทธิ</span>
                          <span>฿{(bd.netAmount || bd.subtotal || 0).toFixed(2)}</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4 mt-6 flex justify-end">
                <button
                  onClick={() => setSelectedBooking(null)}
                  className="rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-2.5 text-xs font-bold transition"
                >
                  ปิด
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
