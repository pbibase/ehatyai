import { prisma } from './prisma';

export async function checkRoomAvailability(
  roomTypeId: string,
  checkInStr: string,
  checkOutStr: string
): Promise<{ available: boolean; remainingCount: number }> {
  if (!checkInStr || !checkOutStr) {
    return { available: false, remainingCount: 0 };
  }

  const checkIn = new Date(checkInStr + 'T00:00:00.000Z');
  const checkOut = new Date(checkOutStr + 'T00:00:00.000Z');

  if (isNaN(checkIn.getTime()) || isNaN(checkOut.getTime()) || checkOut <= checkIn) {
    return { available: false, remainingCount: 0 };
  }

  // Get all dates in the range (excluding checkOut date)
  const dates: Date[] = [];
  const curr = new Date(checkIn);
  while (curr < checkOut) {
    dates.push(new Date(curr));
    curr.setUTCDate(curr.getUTCDate() + 1);
  }

  // Get total inventory count for this RoomType on the target dates
  const roomType = await prisma.roomType.findUnique({
    where: { id: roomTypeId },
    include: {
      inventories: {
        where: {
          date: {
            in: dates
          }
        }
      }
    }
  });

  if (!roomType) {
    return { available: false, remainingCount: 0 };
  }

  // If inventories are not seeded for all nights, it's not available
  if (roomType.inventories.length < dates.length) {
    return { available: false, remainingCount: 0 };
  }

  // Fetch active bookings that overlap with this range
  const activeBookings = await prisma.booking.findMany({
    where: {
      roomTypeId,
      status: {
        in: ['Confirmed', 'Pending-Payment', 'Draft']
      },
      checkIn: {
        lt: checkOut
      },
      checkOut: {
        gt: checkIn
      }
    }
  });

  // Filter bookings to consider only those with active holds/confirmations
  const now = new Date();
  const activeReservations = activeBookings.filter(b => {
    if (b.status === 'Confirmed') return true;
    if (b.holdExpiresAt && b.holdExpiresAt > now) return true;
    return false;
  });

  // Calculate remaining count for each night
  let minRemaining = Infinity;

  for (const date of dates) {
    const inv = roomType.inventories.find(i => {
      // Normalize dates to midnight to compare accurately
      const d1 = new Date(i.date);
      d1.setHours(0,0,0,0);
      const d2 = new Date(date);
      d2.setHours(0,0,0,0);
      return d1.getTime() === d2.getTime();
    });
    
    const totalCount = inv ? inv.totalCount : 0;

    // Count reservations active on this specific date
    const reservationsCount = activeReservations.filter(b => {
      const bIn = new Date(b.checkIn);
      bIn.setHours(0,0,0,0);
      const bOut = new Date(b.checkOut);
      bOut.setHours(0,0,0,0);
      const d = new Date(date);
      d.setHours(0,0,0,0);
      return bIn <= d && bOut > d;
    }).length;

    const remaining = totalCount - reservationsCount;
    if (remaining < minRemaining) {
      minRemaining = remaining;
    }
  }

  const isAvailable = minRemaining > 0 && minRemaining !== Infinity;
  return {
    available: isAvailable,
    remainingCount: isAvailable ? minRemaining : 0
  };
}
