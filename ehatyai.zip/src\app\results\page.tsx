'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Navbar } from '@/components/Navbar';
import { useLanguage } from '@/components/LanguageContext';
import { SlidersHorizontal, ArrowUpDown, MapPin, Star, Award, Wifi } from 'lucide-react';
import Link from 'next/link';

interface Property {
  id: string;
  name: string;
  location: string;
  type: string;
  description: string;
  amenities: string;
  photos: string;
  rating: number;
  roomTypes: { basePrice: number }[];
}

function ResultsContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { t, language } = useLanguage();

  const destination = searchParams.get('destination') || '';
  const checkIn = searchParams.get('checkIn') || '';
  const checkOut = searchParams.get('checkOut') || '';
  const guests = searchParams.get('guests') || '2';

  // Filters & Sorting state
  const [selectedType, setSelectedType] = useState<string>('');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState<number>(5000);
  const [sortBy, setSortBy] = useState<string>('rating_desc');

  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Toggle amenity selection
  const handleAmenityChange = (amenity: string) => {
    setSelectedAmenities(prev =>
      prev.includes(amenity)
        ? prev.filter(a => a !== amenity)
        : [...prev, amenity]
    );
  };

  useEffect(() => {
    setLoading(true);
    const query = new URLSearchParams({
      destination,
      checkIn,
      checkOut,
      guests,
      type: selectedType,
      amenities: selectedAmenities.join(','),
      maxPrice: maxPrice.toString(),
      sortBy,
    });

    fetch(`/api/properties?${query.toString()}`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setProperties(data);
        } else {
          setProperties([]);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setProperties([]);
        setLoading(false);
      });
  }, [destination, checkIn, checkOut, guests, selectedType, selectedAmenities, maxPrice, sortBy]);

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <Navbar />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
        {/* Search header summary */}
        <div className="mb-8 rounded-2xl bg-white p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900">
              {t('results.title')} "{destination || 'ทุกพื้นที่'}"
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              {checkIn && checkOut ? `${checkIn} — ${checkOut} • ` : ''} {guests} guests
            </p>
          </div>
          <button
            onClick={() => router.push('/')}
            className="rounded-lg border border-slate-200 hover:bg-slate-50 px-4 py-2 text-sm font-semibold text-slate-700 transition"
          >
            เปลี่ยนการค้นหา
          </button>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1 flex flex-col gap-6">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
                <h2 className="flex items-center gap-2 text-md font-bold text-slate-900">
                  <SlidersHorizontal className="h-4 w-4 text-blue-500" />
                  {t('results.filter.title')}
                </h2>
                {(selectedType || selectedAmenities.length > 0 || maxPrice < 5000) && (
                  <button
                    onClick={() => {
                      setSelectedType('');
                      setSelectedAmenities([]);
                      setMaxPrice(5000);
                    }}
                    className="text-xs text-blue-600 hover:underline"
                  >
                    ล้างตัวกรอง
                  </button>
                )}
              </div>

              {/* Property Type */}
              <div className="mb-6">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  {t('results.filter.type')}
                </h3>
                <div className="flex flex-col gap-2.5">
                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="property-type"
                      checked={selectedType === ''}
                      onChange={() => setSelectedType('')}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span>ทั้งหมด</span>
                  </label>
                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      id="filter-type-hotel"
                      name="property-type"
                      checked={selectedType === 'Hotel'}
                      onChange={() => setSelectedType('Hotel')}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span>Hotel</span>
                  </label>
                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      id="filter-type-resort"
                      name="property-type"
                      checked={selectedType === 'Resort'}
                      onChange={() => setSelectedType('Resort')}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span>Resort</span>
                  </label>
                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      id="filter-type-apartment"
                      name="property-type"
                      checked={selectedType === 'Apartment'}
                      onChange={() => setSelectedType('Apartment')}
                      className="h-4 w-4 text-blue-600"
                    />
                    <span>Apartment</span>
                  </label>
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  {t('results.filter.price')}
                </h3>
                <input
                  type="range"
                  min="500"
                  max="5000"
                  step="100"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="flex justify-between text-xs text-slate-500 mt-2 font-semibold">
                  <span>฿500</span>
                  <span className="text-blue-600">฿{maxPrice}</span>
                </div>
              </div>

              {/* Amenities */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  {t('results.filter.amenities')}
                </h3>
                <div className="flex flex-col gap-2.5">
                  {['WiFi', 'Pool', 'AC', 'Parking', 'Beachfront', 'Fitness Center'].map((amenity) => (
                    <label key={amenity} className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        id={`filter-amenity-${amenity.toLowerCase().replace(' ', '-')}`}
                        checked={selectedAmenities.includes(amenity)}
                        onChange={() => handleAmenityChange(amenity)}
                        className="h-4 w-4 text-blue-600 rounded border-slate-300"
                      />
                      <span>{amenity}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Properties List */}
          <div className="lg:col-span-3">
            {/* Sorting & Stats */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              <span className="text-sm font-semibold text-slate-500">
                พบที่พักทั้งหมด {properties.length} แห่ง
              </span>
              <div className="flex items-center gap-2">
                <ArrowUpDown className="h-4 w-4 text-slate-400" />
                <span className="text-sm text-slate-500">{t('results.sort')}:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="border-none bg-transparent text-sm font-bold text-slate-800 focus:outline-none focus:ring-0 cursor-pointer"
                >
                  <option value="rating_desc">{t('results.sort.rating.desc')}</option>
                  <option value="price_asc">{t('results.sort.price.asc')}</option>
                </select>
              </div>
            </div>

            {/* List */}
            {loading ? (
              <div className="flex justify-center items-center py-20">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : properties.length > 0 ? (
              <div className="flex flex-col gap-6">
                {properties.map((p) => {
                  const minPrice = p.roomTypes && p.roomTypes.length > 0
                    ? Math.min(...p.roomTypes.map(rt => rt.basePrice))
                    : 0;

                  return (
                    <div
                      key={p.id}
                      onClick={() => router.push(`/properties/${p.id}?checkIn=${checkIn}&checkOut=${checkOut}&guests=${guests}`)}
                      className="property-card cursor-pointer overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm hover:shadow-md transition flex flex-col md:flex-row"
                    >
                      {/* Photo */}
                      <div className="md:w-72 h-48 md:h-auto relative bg-slate-100 flex-shrink-0">
                        <img
                          src={p.photos.split(',')[0]}
                          alt={p.name}
                          className="h-full w-full object-cover"
                        />
                        <span className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm text-xs font-bold text-slate-800 px-2.5 py-1 rounded-full shadow-sm">
                          {p.type}
                        </span>
                      </div>

                      {/* Content */}
                      <div className="flex-1 p-6 flex flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between gap-2">
                            <h3 className="text-lg font-bold text-slate-900 leading-tight">
                              {p.name}
                            </h3>
                            <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded text-amber-700 font-bold text-xs">
                              <Star className="h-3 w-3 fill-amber-500 stroke-amber-500" />
                              <span>{p.rating.toFixed(1)}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 text-slate-500 text-xs mt-1.5 font-medium">
                            <MapPin className="h-3.5 w-3.5" />
                            <span>{p.location}</span>
                          </div>

                          <p className="text-sm text-slate-600 mt-3 line-clamp-2 leading-relaxed">
                            {p.description}
                          </p>

                          {/* Amenities Tags */}
                          <div className="flex flex-wrap gap-1.5 mt-4">
                            {p.amenities.split(',').slice(0, 3).map((a) => (
                              <span key={a} className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-1 rounded">
                                {a.trim()}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* Price & Action */}
                        <div className="border-t border-slate-100 mt-6 pt-4 flex items-center justify-between">
                          <div>
                            <span className="text-xs text-slate-500 block">{t('results.price')}</span>
                            <span className="text-xl font-extrabold text-blue-600">
                              ฿{minPrice.toFixed(2)}
                            </span>
                            <span className="text-xs text-slate-500 font-medium"> / {t('results.night')}</span>
                          </div>
                          
                          <Link
                            href={`/properties/${p.id}?checkIn=${checkIn}&checkOut=${checkOut}&guests=${guests}`}
                            className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-2.5 shadow-sm shadow-blue-500/10 transition"
                          >
                            {t('results.viewDetails')}
                          </Link>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center shadow-sm">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-50 text-red-600 mb-4">
                  <Wifi className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">{t('results.empty')}</h3>
                <p className="text-sm text-slate-500 mt-2 max-w-md mx-auto leading-relaxed">
                  {t('results.empty.suggest')}
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default function Results() {
  return (
    <Suspense fallback={
      <div className="flex min-h-screen justify-center items-center py-20 bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    }>
      <ResultsContent />
    </Suspense>
  );
}
