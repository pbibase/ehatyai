import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const destination = searchParams.get('destination') || '';
    const type = searchParams.get('type') || '';
    const amenities = searchParams.get('amenities') || '';
    const maxPrice = parseFloat(searchParams.get('maxPrice') || '0');
    const sortBy = searchParams.get('sortBy') || 'rating_desc';
    const guests = parseInt(searchParams.get('guests') || '0');

    const where: any = {};

    if (destination) {
      // Decode URI parameter just in case
      const decodedDest = decodeURIComponent(destination).trim();
      const searchTerms = [decodedDest];
      
      const MAPPINGS: Record<string, string> = {
        'หาดใหญ่': 'Hat Yai',
        'สงขลา': 'Songkhla',
        'ลีการ์เดนส์': 'Lee Gardens',
        'สมิหลา': 'Samila',
        'คลองแห': 'Klong Hae',
        'โตนงาช้าง': 'Ton Nga Chang',
        'เมืองเก่า': 'Old Town'
      };

      Object.entries(MAPPINGS).forEach(([th, en]) => {
        if (decodedDest.toLowerCase().includes(th.toLowerCase())) {
          searchTerms.push(en);
        }
      });

      where.OR = searchTerms.flatMap(term => [
        { location: { contains: term } },
        { name: { contains: term } }
      ]);
    }

    if (type) {
      where.type = type;
    }

    let properties = await prisma.property.findMany({
      where,
      include: {
        roomTypes: true
      }
    });

    // 1. Filter by amenities in JS
    if (amenities) {
      const queryAmenities = amenities.split(',').map(a => a.trim().toLowerCase());
      properties = properties.filter(p => {
        const propAmenities = p.amenities.split(',').map(a => a.trim().toLowerCase());
        return queryAmenities.every(qa => propAmenities.includes(qa));
      });
    }

    // 2. Filter by guests count (capacity)
    if (guests > 0) {
      properties = properties.filter(p => 
        p.roomTypes.some(rt => rt.capacity >= guests)
      );
    }

    // 3. Filter by max price
    if (maxPrice > 0) {
      properties = properties.filter(p => 
        p.roomTypes.some(rt => rt.basePrice <= maxPrice)
      );
    }

    // 4. Sort properties
    if (sortBy === 'price_asc') {
      properties.sort((a, b) => {
        const minA = Math.min(...a.roomTypes.map(rt => rt.basePrice), Infinity);
        const minB = Math.min(...b.roomTypes.map(rt => rt.basePrice), Infinity);
        return minA - minB;
      });
    } else {
      // Default to rating_desc
      properties.sort((a, b) => b.rating - a.rating);
    }

    return NextResponse.json(properties);
  } catch (error: any) {
    console.error('API Properties Error:', error);
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
