'use client';

import Link from 'next/link';
import { useLanguage } from './LanguageContext';
import { useSession, signOut } from 'next-auth/react';
import { Globe, Calendar, LogIn, LogOut, User } from 'lucide-react';

export function Navbar() {
  const { language, setLanguage, t } = useLanguage();
  const { data: session } = useSession();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200/80 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand */}
        <Link href="/" className="flex items-center gap-2 text-xl font-bold tracking-tight text-blue-600 transition hover:opacity-90">
          <Globe className="h-6 w-6" />
          <span>{t('nav.title')}</span>
        </Link>

        {/* Right Menu */}
        <div className="flex items-center gap-4">
          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(language === 'th' ? 'en' : 'th')}
            className="flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-sm transition hover:bg-slate-100 hover:text-slate-900"
          >
            <Globe className="h-3.5 w-3.5" />
            <span>{language === 'th' ? 'EN' : 'TH'}</span>
          </button>

          {/* Bookings Link */}
          {session && (
            <Link
              href="/my-bookings"
              className="flex items-center gap-1 text-sm font-medium text-slate-600 transition hover:text-blue-600"
            >
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">{t('nav.bookings')}</span>
            </Link>
          )}

          {/* User Section */}
          {session ? (
            <div className="flex items-center gap-3 border-l border-slate-200 pl-4">
              <div className="hidden flex-col items-end sm:flex">
                <span className="text-xs font-semibold text-slate-700">{session.user?.name}</span>
                <span className="text-[10px] text-slate-500">{session.user?.email}</span>
              </div>
              <button
                onClick={() => signOut({ callbackUrl: '/' })}
                className="flex items-center gap-1 rounded-lg bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-200 hover:text-slate-900"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{t('nav.logout')}</span>
              </button>
            </div>
          ) : (
            <Link
              href="/booking?step=5"
              className="flex items-center gap-1.5 rounded-full bg-blue-600 px-4 py-2 text-xs font-semibold text-white shadow-md shadow-blue-500/20 transition hover:bg-blue-700 hover:shadow-blue-500/30"
            >
              <LogIn className="h-3.5 w-3.5" />
              <span>{t('nav.login')}</span>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
