import { NextResponse } from 'next/server';
import { checkRoomAvailability } from '@/lib/inventory';
import { prisma } from '@/lib/prisma';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const checkIn = searchParams.get('checkIn') || '';
    const checkOut = searchParams.get('checkOut') || '';

    if (!checkIn || !checkOut) {
      return NextResponse.json({ error: 'Missing checkIn or checkOut dates' }, { status: 400 });
    }

    const property = await prisma.property.findUnique({
      where: { id },
      include: { roomTypes: true }
    });

    if (!property) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 });
    }

    const roomAvailabilities = await Promise.all(
      property.roomTypes.map(async (rt) => {
        const avail = await checkRoomAvailability(rt.id, checkIn, checkOut);
        return {
          roomTypeId: rt.id,
          available: avail.available,
          remainingCount: avail.remainingCount,
        };
      })
    );

    return NextResponse.json(roomAvailabilities);
  } catch (error: any) {
    console.error('Availability API error:', error);
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
