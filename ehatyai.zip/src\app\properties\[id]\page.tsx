import { prisma } from '@/lib/prisma';
import { Navbar } from '@/components/Navbar';
import PropertyDetailClient from './PropertyDetailClient';
import { Star, MapPin } from 'lucide-react';

interface PageProps {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}

export default async function PropertyDetailPage({ params, searchParams }: PageProps) {
  const { id } = await params;
  const sParams = await searchParams;
  const checkIn = (sParams.checkIn as string) || '';
  const checkOut = (sParams.checkOut as string) || '';
  const guests = (sParams.guests as string) || '2';

  const property = await prisma.property.findUnique({
    where: { id },
    include: {
      roomTypes: true,
    },
  });

  if (!property) {
    return (
      <div className="flex min-h-screen flex-col bg-slate-50">
        <Navbar />
        <main className="flex-1 flex flex-col items-center justify-center py-20 text-center">
          <h1 className="text-2xl font-bold text-slate-800">ไม่พบโรงแรมที่ท่านเลือก</h1>
          <p className="text-slate-500 mt-2">โปรดกลับไปหน้าหลักเพื่อเลือกที่พักใหม่อีกครั้ง</p>
        </main>
      </div>
    );
  }

  // Pre-serialize photo array and amenities
  const photosArray = property.photos.split(',');
  const amenitiesArray = property.amenities.split(',');

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <Navbar />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
        {/* Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="md:col-span-2 h-[350px] md:h-[450px] rounded-2xl overflow-hidden shadow-sm relative">
            <img src={photosArray[0]} alt={property.name} className="w-full h-full object-cover" />
          </div>
          <div className="hidden md:flex flex-col gap-4 h-[450px]">
            <div className="h-[217px] rounded-2xl overflow-hidden shadow-sm">
              <img src={photosArray[1] || photosArray[0]} alt={property.name} className="w-full h-full object-cover" />
            </div>
            <div className="h-[217px] rounded-2xl overflow-hidden shadow-sm bg-slate-100 flex items-center justify-center text-slate-400 font-semibold relative">
              <img src={photosArray[0]} alt={property.name} className="w-full h-full object-cover opacity-60 filter blur-[2px]" />
              <span className="absolute z-10 text-white bg-slate-900/60 px-4 py-2 rounded-full text-sm">ดูรูปภาพทั้งหมด</span>
            </div>
          </div>
        </div>

        {/* Header Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 flex flex-col gap-6">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="bg-blue-50 text-blue-700 text-xs font-bold px-3 py-1 rounded-full border border-blue-100">
                    {property.type}
                  </span>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-3 leading-tight">
                    {property.name}
                  </h1>
                  <div className="flex items-center gap-1 text-slate-500 text-sm mt-2 font-medium">
                    <MapPin className="h-4 w-4 text-slate-400" />
                    <span>{property.location}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-100 text-amber-800 font-extrabold text-sm flex-shrink-0">
                  <Star className="h-4 w-4 fill-amber-500 stroke-amber-500" />
                  <span>{property.rating.toFixed(1)}</span>
                </div>
              </div>

              <div className="border-t border-slate-100 mt-6 pt-6">
                <h2 className="text-md font-bold text-slate-800">รายละเอียดที่พัก</h2>
                <p className="text-slate-600 text-sm mt-3 leading-relaxed">
                  {property.description}
                </p>
              </div>

              {/* Amenities */}
              <div className="border-t border-slate-100 mt-6 pt-6">
                <h2 className="text-md font-bold text-slate-800">สิ่งอำนวยความสะดวก</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
                  {amenitiesArray.map((amenity) => (
                    <div key={amenity} className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 border border-slate-100 px-3 py-2 rounded-xl">
                      <div className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                      <span>{amenity.trim()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Room Table Section */}
          <div className="lg:col-span-3">
            <PropertyDetailClient
              property={property}
              checkIn={checkIn}
              checkOut={checkOut}
              guests={guests}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
